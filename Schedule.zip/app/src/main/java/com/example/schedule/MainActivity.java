package com.example.schedule;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Intent T_intent = new Intent();
    Bundle T_Bundle = new Bundle();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner Time = (Spinner)findViewById(R.id.time);
        Spinner Hour = (Spinner)findViewById(R.id.hour);
        Spinner Minute = (Spinner)findViewById(R.id.minute);
        Button button;
        button = findViewById(R.id.R_day_button);

        Time.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this,"Time info : "+parent.getItemAtPosition(position),Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent day_repeat = new Intent(MainActivity.this,Dayrepeat.class);
                startActivityForResult(day_repeat,999);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 999){
            if(resultCode == 111){
                Bundle R_bundle = data.getExtras();
                String day = "";
                if(R_bundle != null){
                    
                }
            }
        }
    }
}
