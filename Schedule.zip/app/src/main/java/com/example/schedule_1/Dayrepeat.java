package com.example.schedule_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class Dayrepeat extends AppCompatActivity {

    CheckBox C_mon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dayrepeat);

        Button back = findViewById(R.id.B_button);

        C_mon = findViewById(R.id.C_mon);
        CheckBox C_tue = findViewById(R.id.C_tue);
        CheckBox C_wen = findViewById(R.id.C_wen);
        CheckBox C_thu = findViewById(R.id.C_thu);
        CheckBox C_fri = findViewById(R.id.C_fri);
        CheckBox C_sat = findViewById(R.id.C_sat);
        CheckBox C_sun = findViewById(R.id.C_sun);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent go_back = new Intent();
                Bundle day_data = new Bundle();
                if (C_mon.isChecked()){
                    int day1 = 1;
                    day_data.putInt("day_of_1",day1);
                }
                go_back.putExtras(day_data);
                setResult(111, go_back);
                finish();
            }
        });
    }
}
